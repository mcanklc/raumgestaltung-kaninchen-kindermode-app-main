declare module "vue-router" {
  export declare type LocationQueryRaw = Record<string, any>;
}
