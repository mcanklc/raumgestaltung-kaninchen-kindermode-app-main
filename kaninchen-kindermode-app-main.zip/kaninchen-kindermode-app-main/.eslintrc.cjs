/* eslint-env node */
module.exports = {
  root: true,
  extends: [
    "plugin:vue/vue3-recommended",
    "plugin:tailwindcss/recommended",
    "eslint:recommended",
    "@vue/eslint-config-typescript/recommended",
    "@nuxtjs/eslint-config-typescript",
    "@vue/eslint-config-prettier",
  ],
  env: {
    "vue/setup-compiler-macros": true,
  },
  plugins: ["tailwindcss"],
  settings: {
    tailwindcss: {
      groupByResponsive: true,
      prependCustom: true,
      removeDuplicates: true,
    },
  },
  rules: {
    "@typescript-eslint/no-explicit-any": "off",
    "tailwindcss/no-custom-classname": "off",
    "vue/script-setup-uses-vars": "error",
    "vue/multi-word-component-names": "off",
    "vue/no-multiple-template-root": "off",
    "vue/no-v-html": "off",
    "vue/no-v-model-argument": "off",
  },
};
