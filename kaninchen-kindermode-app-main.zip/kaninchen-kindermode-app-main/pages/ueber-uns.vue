<template>
  <BaseMain>
    <UiIntro
      title="Über uns"
      intro="Wir überarbeiten derzeit noch unsere Über uns Seite, schau einfach später nochmal vorbei."
    />
  </BaseMain>
</template>

<script setup lang="ts">
useHead({
  title: "Über uns",
});
</script>
