export default defineEventHandler((_event: any) => {
  return {
    status: "ok",
  };
});
